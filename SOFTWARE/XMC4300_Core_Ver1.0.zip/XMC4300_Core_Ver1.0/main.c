/*
 * @file XMC4300_Core
 * @date 24 MAR, 2020
 * @version 1.0
 *
 * @brief XMC4300 Core Board EtherCat demo example
 *
 * This example copy and modified from https://www.infineon.com/cms/en/product/promopages/aim-mc/dave_downloads.html
 *
 */

#include <DAVE.h>               //Declarations from DAVE Code Generation (includes SFR declaration)
#include "SSC/Src/XMC_ESCObjects.h"

//Output Enable
	uint8_t outenable;
	void process_stopoutput(){outenable=false;}
	void process_startoutput(){outenable=true;}

//I Love Arduino
	void digitalWrite(XMC_GPIO_PORT_t *const port, const uint8_t pin,uint8_t value)
	{
		XMC_GPIO_SetOutputLevel(port,pin,(value==0||value==false)?XMC_GPIO_OUTPUT_LEVEL_LOW:XMC_GPIO_OUTPUT_LEVEL_HIGH);
	}

void Init_GPIO()
{

	XMC_GPIO_CONFIG_t output = {.mode=XMC_GPIO_MODE_OUTPUT_PUSH_PULL};
	XMC_GPIO_CONFIG_t input = {.mode=XMC_GPIO_MODE_INPUT_TRISTATE};

	//P0_8 is DB_TRST,Must INIT Digital Function.Others pin is normal.
	XMC_GPIO_Init(P2_14,&input);
	XMC_GPIO_Init(P2_9,&input);

	XMC_GPIO_Init(P5_0,&output);
	XMC_GPIO_Init(P0_0,&output);
	XMC_GPIO_Init(P2_5,&output);
	XMC_GPIO_Init(P2_2,&output);
	XMC_GPIO_Init(P1_5,&output);
	XMC_GPIO_Init(P0_8,&output);
	XMC_GPIO_Init(P3_6,&output);
	XMC_GPIO_Init(P3_5,&output);
}

void process_app(TOBJ7000 *OUT_GENERIC, TOBJ6000 *IN_GENERIC)
{
	/* INPUT PROCESSING */
	IN_GENERIC->IN_GEN_Bit1 = XMC_GPIO_GetInput(P2_14);
	IN_GENERIC->IN_GEN_Bit2 = XMC_GPIO_GetInput(P2_9);

	/* OUTPUT PROCESSING */
	digitalWrite(P5_0,OUT_GENERIC->OUT_GEN_Bit1 & outenable);
	digitalWrite(P0_0,OUT_GENERIC->OUT_GEN_Bit2 & outenable);
	digitalWrite(P2_5,OUT_GENERIC->OUT_GEN_Bit3 & outenable);
	digitalWrite(P2_2,OUT_GENERIC->OUT_GEN_Bit4 & outenable);
	digitalWrite(P1_5,OUT_GENERIC->OUT_GEN_Bit5 & outenable);
	digitalWrite(P0_8,OUT_GENERIC->OUT_GEN_Bit6 & outenable);
	digitalWrite(P3_6,OUT_GENERIC->OUT_GEN_Bit7 & outenable);
	digitalWrite(P3_5,OUT_GENERIC->OUT_GEN_Bit8 & outenable);
}

int main(void)
{
  DAVE_STATUS_t status;
  status = DAVE_Init();                     /* Initialization of DAVE APPs  */
  Init_GPIO();                   /* Initialize GPIO */
  if(status == DAVE_STATUS_FAILURE)
  {
    /* Placeholder for error handler code. The while loop below can be replaced with an user error handler. */
    XMC_DEBUG("DAVE APPs initialization failed\n");
    while(1U)
    {
    }
  }
  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {
    MainLoop();
  }
}

/**

 * @brief SYNC0IRQHandler() - EtherCAT Interrupt Routine for SYNC0
 *
 * <b>Details of function</b><br>
 * This routine is handling the SYNC0 Interrupts and need to call the SSC Stack
 */
void SYNC0IRQHandler (void)
{
	Sync0_Isr();
}

/**

 * @brief SYNC1IRQHandler() - EtherCAT Interrupt Routine for SYNC1
 *
 * <b>Details of function</b><br>
 * This routine is handling the SYNC1 Interrupts and need to call the SSC Stack
 */
void SYNC1IRQHandler (void)
{
	Sync1_Isr();
}

/**

 * @brief ENABLE_ESC_INT_USER() - Enabling of user specific EtherCAT Interrupt Routines
 *
 * <b>Details of function</b><br>
 * This routine is called from ECAT_APP on request of SSC stack once interrupts (sync1/sync0) need to be enabled
 */
void ENABLE_ESC_INT_USER()
{
	INTERRUPT_Enable(&INT_SYNC0);
	INTERRUPT_Enable(&INT_SYNC1);
}

/**

 * @brief DISABLE_ESC_INT_USER() - Disabling of user specific EtherCAT Interrupt Routines
 *
 * <b>Details of function</b><br>
 * This routine is called from ECAT_APP on request of SSC stack once interrupts (sync1/sync0) need to be disabled
 */
void DISABLE_ESC_INT_USER()
{
	INTERRUPT_Disable(&INT_SYNC0);
	INTERRUPT_Disable(&INT_SYNC1);
}

